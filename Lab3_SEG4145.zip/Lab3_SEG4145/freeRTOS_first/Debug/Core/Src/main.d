Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal.h \
 ../Core/Inc/stm32l5xx_hal_conf.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_rcc.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32L5xx/Include/stm32l5xx.h \
 ../Drivers/CMSIS/Device/ST/STM32L5xx/Include/stm32l552xx.h \
 ../Drivers/CMSIS/Include/core_cm33.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv8.h \
 ../Drivers/CMSIS/Device/ST/STM32L5xx/Include/system_stm32l5xx.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_rcc_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_gpio.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_gpio_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_dma.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_dma_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_cortex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_adc.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_ll_adc.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_adc_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_exti.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_flash.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_flash_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_flash_ramfunc.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_i2c.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_i2c_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_icache.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_pwr.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_pwr_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_tim.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_tim_ex.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_uart.h \
 ../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_uart_ex.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM33_NTZ/non_secure/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h \
 ../Core/Inc/lcd.h
../Core/Inc/main.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal.h:
../Core/Inc/stm32l5xx_hal_conf.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_rcc.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32L5xx/Include/stm32l5xx.h:
../Drivers/CMSIS/Device/ST/STM32L5xx/Include/stm32l552xx.h:
../Drivers/CMSIS/Include/core_cm33.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv8.h:
../Drivers/CMSIS/Device/ST/STM32L5xx/Include/system_stm32l5xx.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_rcc_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_gpio.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_gpio_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_dma.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_dma_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_cortex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_adc.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_ll_adc.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_adc_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_exti.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_flash.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_flash_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_flash_ramfunc.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_i2c.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_i2c_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_icache.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_pwr.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_pwr_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_tim.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_tim_ex.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_uart.h:
../Drivers/STM32L5xx_HAL_Driver/Inc/stm32l5xx_hal_uart_ex.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM33_NTZ/non_secure/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
../Core/Inc/lcd.h:
